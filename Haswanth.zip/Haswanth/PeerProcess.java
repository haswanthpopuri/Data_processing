import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class PeerProcess {

    private int peerId;
    private int numBits;
    private ConcurrentHashMap<Integer, Record> peerInfoMap;

    public PeerProcess(int peerId, int numBits) {
        this.peerId = peerId;
        this.numBits = numBits;
        this.peerInfoMap = new ConcurrentHashMap<>();
    }

    public void connectToPeer(int remotePeerId, String remoteHost, int remotePort) {
        try {
            // Connect to the remote peer
            Socket downloadSocket = new Socket(remoteHost, remotePort);
            Socket uploadSocket = new Socket(remoteHost, remotePort + 1);
            Socket notificationSocket = new Socket(remoteHost, remotePort + 2);

            // Create a new record for the remote peer
            Record remotePeerRecord = new Record(numBits, remotePeerId, downloadSocket, uploadSocket,
                    notificationSocket);
            peerInfoMap.put(remotePeerId, remotePeerRecord);

            // Send a greeting to the remote peer
            handShakeMessage greeting = new handShakeMessage(peerId);
            greeting.sendGreeting(downloadSocket);

        } catch (IOException e) {
            System.out.println("Failed to connect to the peer " + remotePeerId + ": " + e.getMessage());
        }
    }

    public void handleConnection(Socket incomingSocket) {
        try {
            handShakeMessage greeting = new handShakeMessage(0); // Temporarily set to 0; will be populated with the
                                                                 // remote peer's ID
            greeting.receiveGreeting(incomingSocket);

            int remotePeerId = greeting.getPeerID();

            // Assuming sequential ports for download, upload, and notification
            Socket uploadSocket = new Socket(incomingSocket.getInetAddress(), incomingSocket.getPort() + 1);
            Socket notificationSocket = new Socket(incomingSocket.getInetAddress(), incomingSocket.getPort() + 2);

            // Create and store the remote peer's record
            Record remotePeerRecord = new Record(numBits, remotePeerId, incomingSocket, uploadSocket,
                    notificationSocket);
            peerInfoMap.put(remotePeerId, remotePeerRecord);

        } catch (IOException e) {
            System.out.println("Error handling incoming connection: " + e.getMessage());
        }
    }

    public void sendCommonMessage(int remotePeerId, int type, byte[] data) {
        if (peerInfoMap.containsKey(remotePeerId)) {
            CommonMessage message = new CommonMessage(data.length, type, data);
            Socket socket = peerInfoMap.get(remotePeerId).getDownloadSocket();
            try {
                message.writeTo(socket);
            } catch (IOException e) {
                System.out.println("Failed to send message to the peer " + remotePeerId + ": " + e.getMessage());
            }
        } else {
            System.out.println("Peer " + remotePeerId + " is not connected.");
        }
    }

    public void disconnectPeer(int remotePeerId) {
        if (peerInfoMap.containsKey(remotePeerId)) {
            Record peerRecord = peerInfoMap.remove(remotePeerId);
            try {
                peerRecord.getDownloadSocket().close();
                peerRecord.getUploadSocket().close();
                peerRecord.getNotificationSocket().close();
            } catch (IOException e) {
                System.out.println("Failed to disconnect from the peer " + remotePeerId + ": " + e.getMessage());
            }
        } else {
            System.out.println("Peer " + remotePeerId + " is not connected.");
        }
    }

    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java peerProcess <myPeerID> <numBits> <remotePeerID>");
            return;
        }

        int myPeerID = Integer.parseInt(args[0]);
        int numBits = Integer.parseInt(args[1]);
        int remotePeerID = Integer.parseInt(args[2]);

        PeerProcess myPeer = new PeerProcess(myPeerID, numBits);

        // Example: Connect to another peer with hardcoded host and port
        String remoteHost = "localhost"; // This should be dynamic or read from config
        int remotePort = 8000; // This should be dynamic or read from config
        myPeer.connectToPeer(remotePeerID, remoteHost, remotePort);

        // Start a separate thread for listening to incoming connections
        Thread listenerThread = new Thread(() -> {
            try (ServerSocket serverSocket = new ServerSocket(8001)) { // Assuming our peer is listening on port 8001
                while (true) {
                    Socket incomingSocket = serverSocket.accept();
                    myPeer.handleConnection(incomingSocket);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        listenerThread.start();

        // Example: Sending a message to the remote peer
        String message = "Hello from peer " + myPeerID;
        myPeer.sendCommonMessage(remotePeerID, 2, message.getBytes());

        // Disconnect from the remote peer
        myPeer.disconnectPeer(remotePeerID);
    }
}
